Nino Buliskeria and Jaromir Baxa, "Do Rural Banks Matter that Much?
Burgess and Pande (2005) Reconsidered", Journal of Applied
Econometrics, Vol. 37, No. 6, 2022, pp. 1266-1274.

This file discusses the data and some of the computer programs used to
produce the results in the published paper.

All files are stored in bb-files.zip. Some are ASCII files in DOS
format, and others are binary files.

The paper mainly uses data from Burgess and Pande (2005). There are
two data files -- burgesspandeaerraw.csv and burgesspandeaerfinal.csv
-- both provided by Burgess and Pande. Applying
"burgesspandeaervariables.do" on "burgesspandeaerraw.csv" creates the
variables in "burgesspandeaerfinal.csv" needed to run the regressions
in both papers. Therefore to replicate the manuscript parts 1-4 listed
below, only "burgesspandeaerfinal.csv" is enough. 

The package contains six folders:

ReplicationCode -- replicates Burgess and Pande (2005).

DifferentBreakYear -- replicates BP05 with a changed break year from
the original 1977 to another.

AdditionalBreakYear -- replicates BP05 with an additional break year
together with the original 1977.

MultipleBreaks -- replicates BP05 with the additional break years (up
to five) together with the original 1977.

AdditionalControls -- replicates BP05 with the additional controls. It
  provides data and codes to repeat the exercise mentioned in the
  footnote of the manuscript. It is not in the main part of the paper.
  Nevertheless, the package provides all necessary material for
  replication. There are two data files in bb-files.zip needed to fully
  replicate the exercise -- "additionalcharacteristics.xlsx" and
  "buliskeriabaxafinal.csv". The first provides raw data with
  description and sources, whereas the second buliskeriabaxafinal.csv 
  is needed to replicate the exercise "buliskeriabaxaregressions.do" in
  the "AdditionalControls" folder. 

Figures -- produces more general figures from our paper. 


****************************************
Burgess and Pande (2005) - Data Appendix
****************************************

Our dataset covers 16 Indian states, spans the years 1961–2000, and
comprises a number of different types of variables.

Banking: Bank branch data are from Reserve Bank of India (2000).15 All
bank branch variables are normalized by 1961 state population. Rural
credit, rural saving, and priority sector data span 1969–2000 and are
from an annual publication entitled Statistical Tables Relating to
Banks in India (Reserve Bank of India). Cooperative data span
1969–1992 and are from the same source.

Poverty: Rural, urban, and aggregate headcount figures for 1961–1994
are from Berk Ozler et al. (1996). Data extended to 2000, using the
same methodology, were provided by Gaurav Datt.16 These measures are
based on 25 rounds of the National Sample Survey (NSS).

Wages: Agricultural wage data, which span 1961 to 1998, are from
Agricultural Wages in India (Ministry of Agriculture).17 Factory wages
for 1961 to 1995 are from the Annual Survey of Industries (Central
Statistical Organization).

Policy and Politics: Education, health, and other development
expenditures data, which span 1961 to 1999, are from Public Finance
Statistics (Ministry of Finance) and the Report on Currency and
Finance (Reserve Bank of India). The land reform variable, which spans
1961 to 2000, is from Besley and Burgess (2000). Political variables,
which span 1961 to 2000, are from the State Election Reports (Election
Commission of India). For detail on construction of Congress, Janata,
Hard Left, and Regional political groupings, see Besley and Burgess
(2000).

Deflators and Population: Deflators used are the Consumer Price Index
for Agricultural Laborers (CPIAL) and Consumer Price Index for
Industrial Workers (CPIIW) (reference period October 1973–March 1974)
from Ozler et al. (1996), and have been extended to 2000. Population
and rural location data are from decennial Indian censuses 1961–2001
(Census of India, Registrar General). Rural locations are defined as
towns with fewer than 10,000 persons and villages with between 2,000
and 10,000 persons.


******************************************
Data for exercise with additional controls
******************************************

Infant mortality: State-wise infant mortality per 1000 newborns. 
	
https://www.indiabudget.gov.in/budget_archive/es2003-04/chapt2004/tab95.pdf

Literacy rate: Literacy rates for 1961 Censuses relate to the
population aged five years and above. 

https://www.rbi.org.in/scripts/PublicationsView.aspx?id=18127

Crop production per farmworker: An index of agricultural production
was constructed by multiplying each district's production of each of
12 major crops by an all-India price (Government of India, 1970;
1971). The 12 major crops represent the major grains and cash crops
grown to some degree in all parts of the nation. Districts and regions
which specialize in particular crops can be compared by converting
crop production figures to a common monetary base, using the 1961
all-India prices appropriate to each crop. The same, 1961, prices were
used for indexing both 1961 and 1971 production volume; thus changes
in market prices do not enter into the analysis.

Barnes, D., & Vanneman, R. (1983). Agricultural development and rural
landlessness in India. Studies In Comparative International
Development, 18(1), 90-112.  Table 1. 

Percent laborers of rural farmworkers: The Union Primary Census
Abstract (Government of India, The census definitions do not
distinguish between cultivators who own their land and tenants who
lease it from others. Thus, the category of agricultural laborers
includes only those whose primary occupation is hired labor on farms
cultivated by others--a conservative definition of "rural
proletariat." 1964:1974) reports the number of landed cultivators and
agricultural workers in each district for 1961 and 1971.

Barnes, D., & Vanneman, R. (1983). Agricultural development and rural
landlessness in India. Studies In Comparative International
Development, 18(1), 90-112.  Table 1.

